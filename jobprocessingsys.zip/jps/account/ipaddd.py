import socket
print(socket.gethostbyname(socket.gethostname()))